<div align="center">

<img src="https://capsule-render.vercel.app/api?type=waving&color=0:05070D,50:0B1220,100:05070D&height=230&section=header&text=OLYMPE&fontSize=72&fontColor=29E0FF&animation=fadeIn&fontAlignY=36&desc=Fondateur%20%40DOMIA%20%26%20%40DocFlow%20%C2%B7%20Sous-Chef%20%40ACA&descAlignY=58&descSize=18&descColor=D9B24C" width="100%"/>

<br/>

<img src="https://readme-typing-svg.demolab.com/?font=JetBrains+Mono&weight=500&size=20&duration=3200&pause=900&color=29E0FF&center=true&vCenter=true&width=650&lines=Je+construis+DOMIA+%E2%80%94+immobilier+pan-africain;Je+construis+DocFlow+%E2%80%94+infrastructure+admin;Port-Gentil%2C+Gabon+%E2%86%92+6+pays+et+plus" alt="typing-svg" />

<br/><br/>

![Profile views](https://komarev.com/ghpvc/?username=OLYMP3W&color=29e0ff&style=flat&label=VUES+DU+PROFIL)
![Followers](https://img.shields.io/github/followers/OLYMP3W?label=FOLLOWERS&style=flat&color=d9b24c&labelColor=05070d)

</div>

<br/>

## 🛰️ Portefeuille

<table>
<tr>
<td width="33%" valign="top">

### 🏢 ACA
**Sous-Chef de Projet**

Agence créative et digitale, Port-Gentil. Production éditoriale, identités de marque, exécution client.

</td>
<td width="33%" valign="top">

### 🌍 DOMIA
**Fondateur & CEO**

Plateforme pan-africaine d'annonces immobilières et automobiles pour les marchés francophones.

`6 pays actifs`

</td>
<td width="33%" valign="top">

### 📄 DocFlow
**Fondateur**

Infrastructure SaaS de conformité administrative — le *Canva des documents* pour les PME africaines.

`OS administratif francophone`

</td>
</tr>
</table>

<br/>

## 🌐 Empreinte pan-africaine

```
GABON (siège)
  ├── RDC
  ├── Cameroun
  ├── Bénin
  ├── Guinée
  └── Congo-Brazzaville
```

<br/>

## ⚙️ Stack

<div align="center">
<img src="https://skillicons.dev/icons?i=react,ts,tailwind,supabase,nodejs,python,figma&theme=dark" />
</div>

<br/>

## 📊 Statistiques en direct

<div align="center">

<img height="165" src="https://github-readme-stats.vercel.app/api?username=OLYMP3W&show_icons=true&theme=dark&hide_border=true&bg_color=05070D&title_color=29E0FF&icon_color=D9B24C&text_color=E9EDF6&ring_color=29E0FF"/>
<img height="165" src="https://github-readme-stats.vercel.app/api/top-langs/?username=OLYMP3W&layout=compact&theme=dark&hide_border=true&bg_color=05070D&title_color=29E0FF&text_color=E9EDF6"/>

<br/>

<img src="https://github-readme-streak-stats.herokuapp.com/?user=OLYMP3W&theme=dark&hide_border=true&background=05070D&stroke=29E0FF&ring=29E0FF&fire=D9B24C&currStreakLabel=29E0FF"/>

</div>

<br/>

## 🏆 Trophées

<div align="center">
<img src="https://github-profile-trophy.vercel.app/?username=OLYMP3W&theme=algolia&no-frame=true&column=4&margin-w=8&margin-h=8"/>
</div>

<br/>

## 📈 Activité

<div align="center">
<img src="https://raw.githubusercontent.com/OLYMP3W/OLYMP3W/output/github-contribution-grid-snake.svg" width="100%"/>
</div>

<br/>

## 📡 Trajectoire

| Phase | Étape |
|---|---|
| **Fondation** | Pacte des Fondateurs DOMIA — gouvernance OHADA, vesting 55/15/15/15 |
| **Construction** | DocFlow — de la landing page à l'éditeur temps réel |
| **Expansion** | Suivi terrain sur 6 pays, tableau de bord 8 semaines |

<br/>

<div align="center">

<img src="https://capsule-render.vercel.app/api?type=waving&color=0:05070D,100:0B1220&height=120&section=footer" width="100%"/>

**OLYMPE** — *le futur se construit ici*

</div>
